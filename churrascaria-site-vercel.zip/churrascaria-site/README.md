# Churrascaria Favo de Mel — Site

Site estático em um único arquivo (`index.html`), pronto para publicar na Vercel.

## Como publicar na Vercel

### Opção 1 — Painel da Vercel (mais simples, sem instalar nada)
1. Acesse https://vercel.com e faça login (dá pra usar sua conta do GitHub, Google, etc).
2. Clique em **"Add New..." → "Project"**.
3. Escolha a opção de importar/arrastar uma pasta (**"Deploy"** na aba de importação manual) e selecione esta pasta `churrascaria-site` (ou arraste o arquivo `index.html`).
4. A Vercel detecta como projeto estático automaticamente — não precisa configurar build command nem output directory.
5. Clique em **Deploy** e aguarde. Em segundos o site estará no ar com um link tipo `seu-projeto.vercel.app`.

### Opção 2 — Vercel CLI
1. Instale a CLI (precisa de Node.js instalado):
   ```
   npm i -g vercel
   ```
2. Dentro desta pasta, rode:
   ```
   vercel
   ```
3. Siga as perguntas (login, nome do projeto, etc). Ao final ela te dá o link do site.
4. Para atualizações futuras, depois de editar o `index.html`, rode:
   ```
   vercel --prod
   ```

### Opção 3 — GitHub + Vercel
1. Suba esta pasta para um repositório no GitHub.
2. Na Vercel, clique em **"Add New..." → "Project"** e importe o repositório.
3. Todo push feito no repositório publica uma nova versão automaticamente.

## Domínio próprio
Depois de publicado, em **Project Settings → Domains** dá para adicionar um domínio próprio (ex: churrascariafavodemel.com.br), seguindo as instruções de DNS que a Vercel mostra.

## Editar o site
Todo o site está no arquivo `index.html` (HTML, CSS e JavaScript no mesmo arquivo). Qualquer edição de texto, cores ou imagens pode ser feita direto nesse arquivo.
